const SHEET_NAME = 'Vehicles';

function setup() {
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  let sh = ss.getSheetByName(SHEET_NAME);
  if (!sh) sh = ss.insertSheet(SHEET_NAME);
  const headers = ['id','customer','email','rego','model','year','vin','km','serviceDate','serviceKm','intervalKm','oilSpec','oilCapacity','oilFilter','airFilter','cabinFilter','fuelFilter','notes','businessEmail','lastReminder'];
  if (sh.getLastRow() === 0) sh.appendRow(headers);
  else if (sh.getRange(1,1,1,headers.length).getValues()[0].join('|') !== headers.join('|')) {
    sh.clear(); sh.appendRow(headers);
  }
  ScriptApp.getProjectTriggers().forEach(t => { if (t.getHandlerFunction()==='sendDueReminders') ScriptApp.deleteTrigger(t); });
  ScriptApp.newTrigger('sendDueReminders').timeBased().everyDays(1).atHour(8).create();
  return 'Setup complete. Daily reminder trigger created.';
}

function doGet() {
  return ContentService.createTextOutput(JSON.stringify({ok:true, message:'Mobile Mech Fleet Reminder API'}))
    .setMimeType(ContentService.MimeType.JSON);
}

function doPost(e) {
  try {
    const data = JSON.parse(e.postData.contents || '{}');
    if (data.action === 'upsert') upsertVehicle(data.vehicle, data.businessEmail);
    return ContentService.createTextOutput(JSON.stringify({ok:true})).setMimeType(ContentService.MimeType.JSON);
  } catch(err) {
    return ContentService.createTextOutput(JSON.stringify({ok:false,error:String(err)})).setMimeType(ContentService.MimeType.JSON);
  }
}

function upsertVehicle(v, businessEmail) {
  const sh = SpreadsheetApp.getActiveSpreadsheet().getSheetByName(SHEET_NAME);
  const rows = sh.getDataRange().getValues();
  const idCol = 1;
  let row = -1;
  for (let i=1;i<rows.length;i++) if (String(rows[i][0]) === String(v.id)) { row=i+1; break; }

  const values = [[
    v.id||'',v.customer||'',v.email||'',v.rego||'',v.model||'',v.year||'',v.vin||'',v.km||'',
    v.serviceDate||'',v.serviceKm||'',v.intervalKm||'',v.oilSpec||'',v.oilCapacity||'',v.oilFilter||'',
    v.airFilter||'',v.cabinFilter||'',v.fuelFilter||'',v.notes||'',businessEmail||'',row>0 ? rows[row-1][19] : ''
  ]];
  if (row>0) sh.getRange(row,1,1,values[0].length).setValues(values);
  else sh.appendRow(values[0]);
}

function sendDueReminders() {
  const sh = SpreadsheetApp.getActiveSpreadsheet().getSheetByName(SHEET_NAME);
  if (!sh || sh.getLastRow()<2) return;
  const data = sh.getDataRange().getValues();
  const headers=data[0];
  const idx={}; headers.forEach((h,i)=>idx[h]=i);
  const tz=Session.getScriptTimeZone() || 'Pacific/Auckland';
  const today=new Date(); today.setHours(0,0,0,0);
  const todayStr=Utilities.formatDate(today,tz,'yyyy-MM-dd');

  for(let r=1;r<data.length;r++){
    const row=data[r], due=row[idx.serviceDate];
    if(!due) continue;
    const dueDate = due instanceof Date ? new Date(due) : new Date(String(due)+'T00:00:00');
    dueDate.setHours(0,0,0,0);
    const dueStr=Utilities.formatDate(dueDate,tz,'yyyy-MM-dd');
    if(dueStr !== todayStr) continue;
    if(String(row[idx.lastReminder]||'') === todayStr) continue;

    const customer=row[idx.customer]||'Customer';
    const email=row[idx.email];
    const business=row[idx.businessEmail];
    const rego=row[idx.rego]||'Vehicle';
    const model=row[idx.model]||'';
    const oil=row[idx.oilSpec]||'Not specified';
    const filter=row[idx.oilFilter]||'Not specified';

    const subject='Service reminder — '+rego;
    const body='Hi '+customer+',\\n\\nThis is a reminder from Mobile Mech that '+rego+(model?' ('+model+')':'')+' is due for its scheduled service today.\\n\\nService details on file:\\nOil: '+oil+'\\nOil filter: '+filter+'\\n\\nPlease contact Mobile Mech to arrange the service.\\n\\nRegards,\\nMobile Mech';

    if(email) MailApp.sendEmail({to:email,subject:subject,body:body});
    if(business && business !== email) MailApp.sendEmail({to:business,subject:'Fleet service due — '+rego,body:'Vehicle '+rego+' for '+customer+' is due for service today. Customer email: '+email+'\\n\\nOil: '+oil+'\\nOil filter: '+filter});
    sh.getRange(r+1,idx.lastReminder+1).setValue(todayStr);
  }
}