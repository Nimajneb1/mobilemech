# Mobile Mech Fleet Service Reminder App

## What this version does
- Add customers and vehicles.
- Store registration, make/model, VIN and kilometres.
- Store next service date and service kilometres.
- Store oil specification, oil capacity and filter part numbers.
- Dashboard for due today, upcoming and overdue vehicles.
- Automatically sync saved vehicles to a Google Sheet.
- Google Apps Script sends an email to the customer and your business email on the service due date.
- The email job runs daily at about 8am, so your phone/computer does not need to be on.

## Setup
1. Create a Google Sheet called `Mobile Mech Fleet`.
2. Open Extensions -> Apps Script.
3. Paste the contents of `Code.gs`.
4. Save.
5. Run `setup()` once and approve the Google permissions.
6. Deploy -> New deployment -> Web app.
7. Execute as: Me. Who has access: Anyone.
8. Copy the web app URL.
9. Open `fleet.html` in a browser, or upload it to your existing GitHub website as the Fleet Servicing page.
10. The package also includes `index.html` as a simple home page. The Services dropdown contains Fleet Servicing, and the large white Fleet Servicing text links to `fleet.html`.
11. Paste the Apps Script URL and your business email into the Settings area and click Save settings.

### Important
The app currently stores a browser copy of the vehicles for fast use and syncs changes to the Google Sheet. For production use on multiple devices, the next version should load the master vehicle list from the Sheet as well, rather than relying on the browser copy.

The daily email trigger is handled by Google Apps Script, so it continues running when your computer/phone is off.

## Reminder timing
This first version sends the email on the service expiry date. The UI includes options for 7-day reminders, but the Apps Script currently implements the due-date email. The next version can add the 7-day + due-date schedule.
